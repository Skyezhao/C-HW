#include <cstdio>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
using namespace std;

#define DEFAULT_SIZE 100111

struct HuffmanTreeNode
{
    int weight = 0;
    int minchar = -1;
    HuffmanTreeNode *lc = NULL, *rc = NULL;
};

class Heap
{
public:
	int end;	// size = end + 1
    HuffmanTreeNode **val;
	bool (*cmp)(HuffmanTreeNode *, HuffmanTreeNode *);	// return True if a has higher priority than b
	Heap(bool (*ncmp)(HuffmanTreeNode *, HuffmanTreeNode *))
	{
		val = new HuffmanTreeNode* [DEFAULT_SIZE];
		end = -1;
		cmp = ncmp;
	}
    ~Heap()
    {
        delete[] val;
    }
	void siftup(int now)
	{
		if (now == 0) return;
		int father = (now - 1) / 2;
		if (cmp(val[father], val[now])) return;
		swap(val[father], val[now]);
		siftup(father);
	}
	void insert(HuffmanTreeNode* num)
	{
		end ++;
		val[end] = num;
		siftup(end);
	}
	void siftdown(int now)
	{
		if (now > end) return;
		int lc = now * 2 + 1;
		int rc = now * 2 + 2;
		if (lc <= end)
		{
			if (!cmp(val[now], val[lc]))
			{
				swap(val[now], val[lc]);
				siftdown(lc);
			}
		}
		if (rc <= end)
		{
			if (!cmp(val[now], val[rc]))
			{
				swap(val[now], val[rc]);
				siftdown(rc);
			}
		}
	}
	HuffmanTreeNode* pop()
	{
		HuffmanTreeNode *tmp = val[0];
		val[0] = val[end];
		end --;
		siftdown(0);
		return tmp;
	}
	HuffmanTreeNode* top() { return val[0]; }
};

int my_getchar(char *tmp, int n) // 0 for right cin     i for eof at i th
{
    if (tmp == NULL)
    {
        for (int i = 0; i < n; ++i)
            getchar();
        return 0;
    }
    for (int i = 0; i < n; ++i)
        tmp[i] = getchar();
    return 0;
}

int frequency[256] = {0};
string code[256];

bool getpri(HuffmanTreeNode *a, HuffmanTreeNode *b)
{
    if (a->weight == b->weight)
        return a->minchar < b->minchar;
    else
        return a->weight < b->weight;
}

void getcode(HuffmanTreeNode *now, string nowstr)
{
    if (now->lc == NULL && now->rc == NULL)
    {
        code[now->minchar] = nowstr;
        return;
    }
    if (now->lc != NULL)
        getcode(now->lc, nowstr + '0');
    if (now->rc != NULL)
        getcode(now->rc, nowstr + '1');
}

HuffmanTreeNode* buildTree()
{
	Heap minheap = Heap(&getpri);
    for (int i = 0; i < 256; ++i)
        if (frequency[i] != 0)
        {
            HuffmanTreeNode *tmpnode = new HuffmanTreeNode;
            tmpnode->weight = frequency[i];
            tmpnode->minchar = i;
            tmpnode->lc = NULL;
            tmpnode->rc = NULL;
            minheap.insert(tmpnode);
        }
    while (minheap.end != 0)
    {
        HuffmanTreeNode *tmp1, *tmp2;
        tmp1 = minheap.pop();
        tmp2 = minheap.pop();
        HuffmanTreeNode *newnode = new HuffmanTreeNode;
        newnode->weight = tmp1->weight + tmp2->weight;
        newnode->minchar = min(tmp1->minchar, tmp2->minchar);
        newnode->lc = tmp2;
        newnode->rc = tmp1;
        minheap.insert(newnode);
    }
    HuffmanTreeNode* result = minheap.pop();
    string tmp;
    getcode(result, tmp);
    return result;
}

void my_output(char *str, int *len, char nowc)
{
    str[*len] = nowc;
    *len = *len + 1;
    if (*len == 8)
    {
        unsigned char result = 0;
        for (int i = 0; i < 8; ++i)
            result += ((str[i] - '0') << i);
        cout << result;
        *len = 0;
    }
}

void delt(HuffmanTreeNode *now)
{
    if (now == NULL) return;
    if (now->lc != NULL) delt(now->lc);
    if (now->rc != NULL) delt(now->rc);
    delete now;
}

string atext;

void getdecode(HuffmanTreeNode *now, int *len, int *charnum)
{
    if (now->lc == NULL && now->rc == NULL)
    {
        *charnum += 1;
        cout << (unsigned char)now->minchar;
        return;
    }
    if (atext[*len] == '0')
    {
        *len += 1;
        getdecode(now->lc, len, charnum);
    }
    else
    {
        *len += 1;
        getdecode(now->rc, len, charnum);
    }
}

int main()
{
    freopen("hahatmp.in", "r", stdin);
    freopen("haha.in", "w", stdout);
    char modetmp[6];
    my_getchar(modetmp, 6);
    if (strcmp(modetmp, "ENCODE") == 0)
    {
        cout << "DECODE";
        int charnum = 0;
        string text;
        unsigned char tmpcx;
        while (cin.get((char &) tmpcx))
        {
            charnum ++;
            frequency[tmpcx] ++;
            text.push_back(tmpcx);
        }
        HuffmanTreeNode *root = NULL;
        if (charnum)
            root = buildTree();
        cout << "HUFFMAN";
        unsigned char tmpxxx = 0;
        cout << tmpxxx;
        for (int i = 0; i < 256; ++i)
        {
            unsigned int tmpf = frequency[i];
            for (int j = 0; j < 4; ++j)
            {
                unsigned char tmpout = 0;
                for (int k = 0; k < 8; ++k)
                {
                    tmpout += ((tmpf & 1) << k);
                    tmpf >>= 1;
                }
                cout << tmpout;
            }
        }
        string result;
        for (int i = 0; i < text.length(); ++i)
        	result += code[(unsigned char)text[i]];
        while (result.length() % 8 != 0)
            result += '0';
        for (int i = 0; i < result.length() / 8; ++i)
        {
        	unsigned char tmpc = 0;
        	for (int j = 0; j < 8; ++j)
        		tmpc += ((result[i*8+j] - '0') << j);
        	cout << tmpc;
		}
        delt(root);
    }
    else if (strcmp(modetmp, "DECODE") == 0)
    {
        unsigned int allcharnum = 0;
        my_getchar(NULL, 8);
        for (int i = 0; i < 256; ++i)
        {
            unsigned int tmp = 0;
            unsigned int tmpx;
            for (int j = 0; j < 4; ++j)
            {
                tmpx = getchar();
                tmp += (tmpx << (j*8));
            }
            frequency[i] = tmp;
            allcharnum += tmp;
        }
        if (!allcharnum) return 0;
        HuffmanTreeNode *root = buildTree();
        unsigned char tmpc;
        while (cin.get((char &) tmpc))
        {
            for (int i = 0; i < 8; ++i)
            {
                atext += '0' + (tmpc & 1);
                tmpc >>= 1;
            }
        }

        //cout << atext << endl;
        int nowlen = 0, nowcharnum = 0;
        while (nowlen < atext.length() && nowcharnum != allcharnum)
            getdecode(root, &nowlen, &nowcharnum);
        delt(root);
    }
    return 0;
}
