#!/bin/bash

while true; do
./haha
./Huffman2
./Huffman
./2

if diff hehe1.out hehe2.out; then
 printf "Accepted\n"
else
 printf "Wrong Answer\n"
 break
fi

done