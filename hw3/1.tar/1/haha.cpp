#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <ctime>
using namespace std;

int main()
{
	freopen("hahatmp.in", "w", stdout);
	srand(time(0));
	int n = 5;
	cout << "ENCODE";
	for (int i = 1; i <= n; ++i)
		printf("%c", (unsigned char)(rand() % 128));
	return 0;
}
